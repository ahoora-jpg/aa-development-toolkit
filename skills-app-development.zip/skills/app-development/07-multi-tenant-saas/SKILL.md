# Multi-Tenant / SaaS Architecture

Status: Draft
Last reviewed: 2026-07-26

## Purpose

How to design an application that serves many separate customers (tenants) from one codebase/infrastructure, while keeping each tenant's data isolated and performance predictable.

## Key Sources

### Multi-tenant data architecture patterns (reference notes)

Source:
https://gist.github.com/santoshshinde2012/671920fbb4a877438b76cd2e004d2078

Notes: A widely-referenced summary of the three standard tenant-isolation models (shared database/shared schema, shared database/schema-per-tenant, database-per-tenant) with their tradeoffs — treat as a starting checklist, verify against current vendor docs (AWS/Azure/GCP each publish their own multi-tenant SaaS guidance) before committing to one model.

## Core Concepts To Apply

- **Tenant isolation models**:
  - *Shared DB, shared schema* (a `tenant_id` column on every table) — cheapest to run, easiest to migrate schema, but requires strict discipline: every single query must filter by `tenant_id`, or one bug leaks data across customers.
  - *Shared DB, schema-per-tenant* — stronger isolation, still one database server to manage, but migrations must run against every schema.
  - *Database-per-tenant* — strongest isolation, easiest to meet strict compliance/data-residency requirements, most operational overhead (backups, migrations, scaling all multiply by tenant count).
  - Decision guide: start with shared schema + `tenant_id` for most SaaS products; move specific large or compliance-sensitive tenants to their own database only when actually required.
- **Enforce isolation at the framework level, not per-query**: use a database/ORM feature (row-level security, a query middleware that auto-injects `tenant_id`) so a missing `WHERE tenant_id = ?` isn't possible to forget — don't rely on every developer remembering it manually.
- **Tenant-aware authentication**: a user's session/token should carry which tenant(s) they belong to; authorization checks must confirm both "can this user do X" and "does X belong to their tenant."
- **Noisy-neighbor mitigation**: one tenant's heavy usage (large data export, traffic spike) should not degrade performance for other tenants — use per-tenant rate limits/quotas, and consider queue-based isolation for expensive background jobs.
- **Per-tenant configuration**: design a clean way to store tenant-specific settings/feature flags/branding separate from the core schema, so customization doesn't turn into per-tenant code forks.

## When To Use

Apply from the start if the product is explicitly B2B/SaaS with multiple customer organizations — retrofitting tenant isolation onto a single-tenant schema later is a major migration.

## External Sources

The gist above is a widely-cited community reference, not an official spec — cross-check against your cloud provider's current multi-tenant SaaS architecture guidance for anything going to production.
