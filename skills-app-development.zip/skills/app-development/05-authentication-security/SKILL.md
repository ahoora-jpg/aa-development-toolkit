# Authentication & Security

Status: Draft
Last reviewed: 2026-07-26

## Purpose

Baseline security practices for a modern application: authenticating users, authorizing actions, and avoiding the most common vulnerability classes. This is not a substitute for a real security review on anything handling sensitive data — it's the minimum floor.

## Key Sources

### OWASP API Security Top 10

Repository:
https://github.com/OWASP/API-Security

Notes: The authoritative, community-maintained list of the most critical API security risks (broken object-level authorization, broken authentication, excessive data exposure, lack of rate limiting, etc.), maintained by OWASP.

### Awesome API Security

Repository:
https://github.com/arainho/awesome-api-security

Notes: Curated list of tools, checklists, and articles specifically for testing and hardening API security, complementary to the OWASP list above.

## Core Concepts To Apply

- **Authentication vs authorization**: authentication proves who the user is (login); authorization decides what they're allowed to do. Check both on every request — a common bug class is authenticating correctly but forgetting to check the specific resource the user is trying to access ("broken object-level authorization," OWASP's #1 API risk).
- **Sessions vs tokens (JWT)**: server-side sessions are simpler to revoke (log a user out instantly); JWTs are stateless and scale better across services but are hard to revoke early — if using JWTs, keep access tokens short-lived and use a refresh-token flow.
- **OAuth2 / OIDC**: use a standard library/provider for third-party login and SSO rather than hand-rolling token exchange — this is a well-understood area with many subtle failure modes.
- **Input validation**: validate and sanitize all input at the API boundary (type, length, format) before it touches business logic or the database — this is the first line of defense against injection attacks.
- **Secrets management**: never commit API keys/passwords to the repository; use environment variables or a secrets manager, and rotate credentials that were ever exposed.
- **Rate limiting**: apply per-user/per-IP rate limits on authentication endpoints and any expensive operation to blunt brute-force and abuse.

## When To Use

Apply from day one on any endpoint handling user data, and re-check this list before shipping any feature that changes who can see or modify what.

## External Sources

Both sources above are external, actively maintained by OWASP and the community — link to them rather than duplicating their content, since security guidance changes as new vulnerability classes are discovered.
