# API Design

Status: Draft
Last reviewed: 2026-07-26

## Purpose

Conventions for designing APIs (mainly REST, with notes on when GraphQL or async/event APIs fit better) so multiple frontends (web, mobile, third parties) can consume them predictably.

## Key Sources

### OpenAPI Specification

Repository:
https://github.com/OAI/OpenAPI-Specification

Notes: The industry-standard way to describe a REST API's shape (endpoints, request/response schemas, auth). Use it to generate docs, client SDKs, and server stubs, and to keep the API contract explicit rather than implicit in code.

### AsyncAPI Specification

Site/repo referenced via:
https://www.asyncapi.com

Notes: The equivalent of OpenAPI for event-driven/async APIs (message queues, websockets). Useful once the app has real-time or pub/sub endpoints (see 08-realtime-event-driven).

## Core Conventions

- **Resource-oriented URLs**: `/orders/123/items`, not `/getOrderItems?orderId=123`. Nouns, not verbs; HTTP methods (GET/POST/PATCH/DELETE) carry the verb.
- **Versioning**: version the API from day one (`/v1/...` or an `Accept` header), even with one consumer — retrofitting versioning later is painful.
- **Pagination**: cursor-based pagination for anything that can grow large (feeds, lists); offset pagination is fine for small, bounded lists only.
- **Consistent error format**: a single JSON error shape across all endpoints (e.g. `{ "error": { "code", "message", "details" } }`) so clients can handle errors generically.
- **Idempotency**: make PUT/DELETE idempotent by design; for POST actions that must not double-fire (payments, order creation), support an idempotency key.
- **REST vs GraphQL vs gRPC**: REST for public/simple APIs and broad client compatibility; GraphQL when clients need flexible, nested data shapes and over/under-fetching is a real problem; gRPC for internal service-to-service calls where performance and strict typing matter more than human readability.

## When To Use

Apply at the start of any new API surface, and whenever adding a new resource — check it fits the existing URL/versioning/error conventions rather than inventing a new pattern per endpoint.

## External Sources

OpenAPI and AsyncAPI are external, actively maintained standards/specifications — link to the spec rather than reproducing it.
